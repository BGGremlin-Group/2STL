@echo off
python img3d_app.py
