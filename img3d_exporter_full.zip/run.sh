#!/usr/bin/env bash
python img3d_app.py
