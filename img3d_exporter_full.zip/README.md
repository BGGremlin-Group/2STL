# IMG3D Exporter (Relief + Figurine) — Standalone (FastAPI)

A local-only web app that converts:
- **Single image → watertight bas-relief / lithophane** (great for plaques, coins, keychains)
- **Multi-angle images / ZIP / turntable video → 3D figurine** (photogrammetry job pipeline)

Exports: **STL / OBJ / PLY / GLB**

This project is designed to run **entirely locally** on your machine, serving a web UI at:
`http://127.0.0.1:8000`

---

## 1) Install Python dependencies

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

> If you're on Termux/Android or ARM platforms, relief mode will still work.
> Figurine mode requires external photogrammetry tools (below).

---

## 2) Run the app

```bash
python img3d_app.py
```

Then open:
- http://127.0.0.1:8000

---

## 3) Figurine mode prerequisites (photogrammetry engines)

Figurine mode needs *at least one* engine installed and available in PATH:

### Option A — COLMAP (CPU or CUDA GPU build)
- Provide `colmap` executable in PATH.
- GPU acceleration works only if your COLMAP build supports CUDA.

### Option B — Meshroom (GPU-friendly)
- Provide `meshroom_batch` executable in PATH.

### Optional (for video input)
- Provide `ffmpeg` executable in PATH (for turntable video frame extraction).

You can check what your backend detects at:
- http://127.0.0.1:8000/api/health

---

## 4) Notes on Android / Termux

- **Relief mode** (single image) works with pure Python deps.
- **Figurine mode** depends on native tools (COLMAP/Meshroom/ffmpeg). Those are not typically
  available via `pip` and can be difficult on mobile. If the tools are missing,
  the app will show a clear error message in the Figurine logs.

---

## Project layout

- `img3d_app.py` — FastAPI backend + job runner + exports
- `static/index.html` — UI (no external CDN imports) with built-in STL preview renderer
- `requirements.txt` — Python requirements

---

## Security

This runs locally and listens on `127.0.0.1` by default. Do not expose it publicly without adding
authentication and hardening.

---

## License

MIT (see LICENSE).
