#!/usr/bin/env python3
from __future__ import annotations

import io
import os
import json
import uuid
import time
import glob
import shutil
import zipfile
import tempfile
import threading
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image, ImageFilter, ImageOps
import trimesh

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import HTMLResponse, Response, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

APP_TITLE = "IMG3D Exporter (Relief + Figurine) • STL/OBJ/PLY/GLB"
HOST = "127.0.0.1"
PORT = 8000

SUPPORTED_EXPORTS = ("stl", "obj", "ply", "glb")

RELIEF_DEFAULTS: Dict[str, Any] = {
    "mode": "relief",
    "format": "stl",
    "width_mm": 120.0,
    "base_mm": 2.0,
    "relief_mm": 3.0,
    "pixels_wide": 420,
    "crop": [0, 0, 1, 1],
    "invert": False,
    "blur": 1.0,
    "black": 0.0,
    "white": 1.0,
    "gamma": 1.0,
    "auto_contrast": True,
}

FIGURINE_DEFAULTS: Dict[str, Any] = {
    "engine": "auto",     # auto | colmap | meshroom
    "device": "auto",     # auto | cpu | gpu
    "format": "stl",
    "quality": "medium",  # draft | medium | high
    "mesher": "poisson",  # poisson | delaunay (COLMAP)
    "frame_step": 6,      # video: keep every Nth frame
    "max_frames": 160,    # cap extracted frames
    "max_images": 160,    # sample/limit images to avoid overload
}

def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)

def run_cmd(cmd: List[str], cwd: Optional[Path] = None, env: Optional[Dict[str, str]] = None, log_cb=None) -> None:
    if log_cb:
        log_cb(f"$ {' '.join(cmd)}")
    p = subprocess.Popen(
        cmd,
        cwd=str(cwd) if cwd else None,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True,
    )
    assert p.stdout is not None
    for line in p.stdout:
        line = line.rstrip("\n")
        if log_cb and line:
            log_cb(line)
    rc = p.wait()
    if rc != 0:
        raise RuntimeError(f"Command failed (exit {rc}): {' '.join(cmd)}")

def safe_float_list(x, n=4, default=None):
    if default is None:
        default = [0, 0, 1, 1]
    try:
        if isinstance(x, str):
            parts = [float(p.strip()) for p in x.split(",")]
        else:
            parts = [float(v) for v in x]
        if len(parts) != n:
            return default
        return parts
    except Exception:
        return default

def sanitize_images(folder: Path) -> List[Path]:
    exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
    imgs = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in exts]
    return sorted(imgs, key=lambda p: p.name.lower())

def sample_images(files: List[Path], max_images: int) -> List[Path]:
    if max_images <= 0 or len(files) <= max_images:
        return files
    # Evenly sample to max_images
    idx = np.linspace(0, len(files) - 1, max_images).astype(int)
    return [files[i] for i in idx]

# --------------------------
# Relief / Lithophane mesh
# --------------------------

def _as_float01(gray: Image.Image) -> np.ndarray:
    arr = np.asarray(gray, dtype=np.float32) / 255.0
    return np.clip(arr, 0.0, 1.0)

def _apply_levels(h: np.ndarray, black=0.0, white=1.0, gamma=1.0) -> np.ndarray:
    black = float(np.clip(black, 0.0, 1.0))
    white = float(np.clip(white, 0.0, 1.0))
    if white <= black + 1e-6:
        white = min(1.0, black + 1e-6)
    h = np.clip(h, black, white)
    h = (h - black) / (white - black)
    gamma = max(0.05, float(gamma))
    h = np.power(h, 1.0 / gamma)
    return h

def image_to_relief_mesh(
    image_bytes: bytes,
    mode: str = "relief",
    width_mm: float = 120.0,
    base_mm: float = 2.0,
    relief_mm: float = 3.0,
    pixels_wide: int = 420,
    crop: Tuple[float, float, float, float] = (0, 0, 1, 1),
    invert: bool = False,
    blur: float = 1.0,
    black: float = 0.0,
    white: float = 1.0,
    gamma: float = 1.0,
    auto_contrast: bool = True,
) -> trimesh.Trimesh:
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")

    # Crop by fractional box
    W, H = img.size
    l, t, r, b = crop
    lpx = int(np.clip(l, 0, 1) * W)
    tpx = int(np.clip(t, 0, 1) * H)
    rpx = int(np.clip(r, 0, 1) * W)
    bpx = int(np.clip(b, 0, 1) * H)
    if rpx <= lpx + 2: rpx = min(W, lpx + 2)
    if bpx <= tpx + 2: bpx = min(H, tpx + 2)
    img = img.crop((lpx, tpx, rpx, bpx))

    # Resize preserve aspect
    w_target = int(max(96, pixels_wide))
    aspect = img.size[1] / img.size[0]
    h_target = int(max(96, round(w_target * aspect)))
    img = img.resize((w_target, h_target), Image.LANCZOS)

    gray = ImageOps.grayscale(img)
    if blur and float(blur) > 0:
        gray = gray.filter(ImageFilter.GaussianBlur(radius=float(blur)))

    h = _as_float01(gray)

    if mode.lower() == "lithophane":
        invert = True if invert is False else invert

    if invert:
        h = 1.0 - h

    if auto_contrast:
        hmin, hmax = float(h.min()), float(h.max())
        if hmax > hmin + 1e-6:
            h = (h - hmin) / (hmax - hmin)

    h = _apply_levels(h, black=black, white=white, gamma=gamma)

    width_mm = float(width_mm)
    height_mm = width_mm * (h_target / w_target)
    base_mm = float(base_mm)
    relief_mm = float(relief_mm)

    xs = np.linspace(0.0, width_mm, w_target, dtype=np.float32)
    ys = np.linspace(0.0, height_mm, h_target, dtype=np.float32)
    X, Y = np.meshgrid(xs, ys)
    Z_top = (base_mm + h * relief_mm).astype(np.float32)
    Z_bot = np.zeros_like(Z_top, dtype=np.float32)

    v_top = np.column_stack([X.ravel(), Y.ravel(), Z_top.ravel()]).astype(np.float32)
    v_bot = np.column_stack([X.ravel(), Y.ravel(), Z_bot.ravel()]).astype(np.float32)

    def idx(i: int, j: int) -> int:
        return j * w_target + i

    faces: List[List[int]] = []

    # Top
    for j in range(h_target - 1):
        for i in range(w_target - 1):
            a = idx(i, j)
            b = idx(i + 1, j)
            c = idx(i + 1, j + 1)
            d = idx(i, j + 1)
            faces.append([a, b, c])
            faces.append([a, c, d])

    # Bottom
    off = v_top.shape[0]
    for j in range(h_target - 1):
        for i in range(w_target - 1):
            a = off + idx(i, j)
            b = off + idx(i, j + 1)
            c = off + idx(i + 1, j + 1)
            d = off + idx(i + 1, j)
            faces.append([a, b, c])
            faces.append([a, c, d])

    # Side walls
    for j in range(h_target - 1):  # left
        a = idx(0, j)
        b = idx(0, j + 1)
        c = off + idx(0, j + 1)
        d = off + idx(0, j)
        faces.append([a, b, c])
        faces.append([a, c, d])

    for j in range(h_target - 1):  # right
        a = idx(w_target - 1, j)
        b = off + idx(w_target - 1, j)
        c = off + idx(w_target - 1, j + 1)
        d = idx(w_target - 1, j + 1)
        faces.append([a, b, c])
        faces.append([a, c, d])

    for i in range(w_target - 1):  # bottom edge
        a = idx(i, 0)
        b = off + idx(i, 0)
        c = off + idx(i + 1, 0)
        d = idx(i + 1, 0)
        faces.append([a, b, c])
        faces.append([a, c, d])

    for i in range(w_target - 1):  # top edge
        a = idx(i, h_target - 1)
        b = idx(i + 1, h_target - 1)
        c = off + idx(i + 1, h_target - 1)
        d = off + idx(i, h_target - 1)
        faces.append([a, b, c])
        faces.append([a, c, d])

    vertices = np.vstack([v_top, v_bot])
    faces_np = np.asarray(faces, dtype=np.int64)

    mesh = trimesh.Trimesh(vertices=vertices, faces=faces_np, process=True)
    mesh.remove_duplicate_faces()
    mesh.remove_degenerate_faces()
    mesh.remove_unreferenced_vertices()
    mesh.fix_normals()
    return mesh

# --------------------------
# Export helpers
# --------------------------

def export_mesh(mesh: trimesh.Trimesh, fmt: str) -> bytes:
    fmt = fmt.lower().strip(".")
    if fmt not in SUPPORTED_EXPORTS:
        raise ValueError(f"Unsupported format: {fmt}")
    out = mesh.export(file_type=fmt)
    if isinstance(out, str):
        return out.encode("utf-8")
    return out

def load_any_mesh(path: Path) -> trimesh.Trimesh:
    m = trimesh.load(str(path), force="mesh")
    if isinstance(m, trimesh.Scene):
        m = trimesh.util.concatenate(tuple(m.dump().geometry.values()))
    assert isinstance(m, trimesh.Trimesh)
    m.remove_duplicate_faces()
    m.remove_degenerate_faces()
    m.remove_unreferenced_vertices()
    m.fix_normals()
    return m

# --------------------------
# Figurine: engines
# --------------------------

def extract_frames_with_ffmpeg(video_path: Path, out_dir: Path, frame_step: int, max_frames: int, log_cb=None) -> None:
    if not which("ffmpeg"):
        raise RuntimeError("ffmpeg not found in PATH. Install FFmpeg or upload images instead of video.")
    out_dir.mkdir(parents=True, exist_ok=True)
    pattern = str(out_dir / "frame_%05d.jpg")
    vf = f"select='not(mod(n\\,{frame_step}))',scale=1600:-1"
    cmd = ["ffmpeg", "-y", "-i", str(video_path), "-vf", vf, "-q:v", "2", pattern]
    run_cmd(cmd, cwd=out_dir, log_cb=log_cb)

    frames = sorted(out_dir.glob("frame_*.jpg"))
    if len(frames) > max_frames:
        for p in frames[max_frames:]:
            p.unlink(missing_ok=True)
        if log_cb:
            log_cb(f"Trimmed frames to max_frames={max_frames}.")

def find_meshroom_mesh(output_dir: Path) -> Optional[Path]:
    candidates = []
    candidates += glob.glob(str(output_dir / "**" / "texturedMesh.obj"), recursive=True)
    candidates += glob.glob(str(output_dir / "**" / "texturedMesh.ply"), recursive=True)
    candidates += glob.glob(str(output_dir / "**" / "mesh.obj"), recursive=True)
    candidates += glob.glob(str(output_dir / "**" / "mesh.ply"), recursive=True)
    if not candidates:
        return None
    candidates = sorted(candidates, key=lambda s: (0 if "texturedMesh.obj" in s else 1, len(s)))
    return Path(candidates[0])

def run_meshroom(images_dir: Path, work_dir: Path, log_cb=None) -> Path:
    exe = which("meshroom_batch")
    if not exe:
        raise RuntimeError("meshroom_batch not found in PATH. Install Meshroom or use COLMAP engine.")
    out_dir = work_dir / "meshroom_out"
    out_dir.mkdir(parents=True, exist_ok=True)

    cmd = [exe, "--input", str(images_dir), "--output", str(out_dir)]
    run_cmd(cmd, cwd=work_dir, log_cb=log_cb)

    mesh_path = find_meshroom_mesh(out_dir)
    if not mesh_path or not mesh_path.exists():
        raise RuntimeError("Meshroom finished but no mesh was found in output.")
    return mesh_path

def run_colmap_to_dense(images_dir: Path, work_dir: Path, use_gpu: bool, quality: str, log_cb=None) -> Path:
    exe = which("colmap")
    if not exe:
        raise RuntimeError("colmap not found in PATH. Install COLMAP, or use Meshroom engine.")

    db = work_dir / "database.db"
    sparse = work_dir / "sparse"
    dense = work_dir / "dense"
    sparse.mkdir(exist_ok=True)
    dense.mkdir(exist_ok=True)

    if quality == "draft":
        pm_geom = "false"
        pm_iters = "3"
    elif quality == "high":
        pm_geom = "true"
        pm_iters = "7"
    else:
        pm_geom = "true"
        pm_iters = "5"

    gpu_flag = "1" if use_gpu else "0"

    run_cmd([
        exe, "feature_extractor",
        "--database_path", str(db),
        "--image_path", str(images_dir),
        "--ImageReader.single_camera", "1",
        "--SiftExtraction.use_gpu", gpu_flag,
    ], cwd=work_dir, log_cb=log_cb)

    run_cmd([
        exe, "exhaustive_matcher",
        "--database_path", str(db),
        "--SiftMatching.use_gpu", gpu_flag,
    ], cwd=work_dir, log_cb=log_cb)

    run_cmd([
        exe, "mapper",
        "--database_path", str(db),
        "--image_path", str(images_dir),
        "--output_path", str(sparse),
    ], cwd=work_dir, log_cb=log_cb)

    models = sorted([p for p in sparse.iterdir() if p.is_dir()], key=lambda p: p.name)
    if not models:
        raise RuntimeError("COLMAP mapper produced no sparse model.")
    model = models[-1]

    run_cmd([
        exe, "image_undistorter",
        "--image_path", str(images_dir),
        "--input_path", str(model),
        "--output_path", str(dense),
        "--output_type", "COLMAP",
    ], cwd=work_dir, log_cb=log_cb)

    run_cmd([
        exe, "patch_match_stereo",
        "--workspace_path", str(dense),
        "--workspace_format", "COLMAP",
        "--PatchMatchStereo.geom_consistency", pm_geom,
        "--PatchMatchStereo.max_num_iterations", pm_iters,
        "--PatchMatchStereo.gpu_index", "0",
        "--PatchMatchStereo.use_gpu", gpu_flag,
    ], cwd=work_dir, log_cb=log_cb)

    fused = dense / "fused.ply"
    run_cmd([
        exe, "stereo_fusion",
        "--workspace_path", str(dense),
        "--workspace_format", "COLMAP",
        "--input_type", "geometric",
        "--output_path", str(fused),
    ], cwd=work_dir, log_cb=log_cb)

    if not fused.exists():
        raise RuntimeError("COLMAP stereo_fusion did not produce fused.ply.")
    return dense

def run_colmap_mesher(dense_dir: Path, method: str, log_cb=None) -> Path:
    exe = which("colmap")
    if not exe:
        raise RuntimeError("colmap not found in PATH.")
    fused = dense_dir / "fused.ply"
    if not fused.exists():
        raise RuntimeError("Expected fused.ply not found. Dense reconstruction probably failed.")

    method = (method or "poisson").lower()
    if method not in ("poisson", "delaunay"):
        method = "poisson"

    out_path = dense_dir / f"meshed-{method}.ply"
    if method == "poisson":
        cmd = [exe, "poisson_mesher", "--input_path", str(fused), "--output_path", str(out_path)]
    else:
        cmd = [exe, "delaunay_mesher", "--input_path", str(fused), "--output_path", str(out_path)]
    run_cmd(cmd, cwd=dense_dir, log_cb=log_cb)

    if not out_path.exists():
        raise RuntimeError(f"COLMAP {method}_mesher did not produce output mesh.")
    return out_path

def choose_engine(engine: str, device: str) -> str:
    engine = (engine or "auto").lower()
    device = (device or "auto").lower()
    have_colmap = which("colmap") is not None
    have_meshroom = which("meshroom_batch") is not None
    if engine != "auto":
        return engine
    if device == "gpu" and have_meshroom:
        return "meshroom"
    if have_colmap:
        return "colmap"
    if have_meshroom:
        return "meshroom"
    return "none"

# --------------------------
# Job manager
# --------------------------

@dataclass
class Job:
    id: str
    kind: str
    status: str = "queued"
    progress: float = 0.0
    logs: List[str] = field(default_factory=list)
    error: Optional[str] = None
    result_path: Optional[str] = None
    result_fmt: Optional[str] = None
    created_at: float = field(default_factory=time.time)

class JobManager:
    def __init__(self):
        self._jobs: Dict[str, Job] = {}
        self._lock = threading.Lock()

    def create(self, kind: str) -> Job:
        j = Job(id=uuid.uuid4().hex, kind=kind)
        with self._lock:
            self._jobs[j.id] = j
        return j

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            return self._jobs.get(job_id)

    def log(self, job_id: str, msg: str) -> None:
        with self._lock:
            j = self._jobs.get(job_id)
            if not j:
                return
            if len(j.logs) > 800:
                j.logs = j.logs[-600:]
            j.logs.append(msg)

    def set_status(self, job_id: str, status: str, progress: Optional[float] = None) -> None:
        with self._lock:
            j = self._jobs.get(job_id)
            if not j:
                return
            j.status = status
            if progress is not None:
                j.progress = float(progress)

    def set_result(self, job_id: str, path: Path, fmt: str) -> None:
        with self._lock:
            j = self._jobs.get(job_id)
            if not j:
                return
            j.result_path = str(path)
            j.result_fmt = fmt
            j.status = "done"
            j.progress = 1.0

    def set_error(self, job_id: str, err: str) -> None:
        with self._lock:
            j = self._jobs.get(job_id)
            if not j:
                return
            j.status = "error"
            j.error = err

JOBS = JobManager()

# --------------------------
# FastAPI app
# --------------------------

app = FastAPI(title=APP_TITLE)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

@app.get("/", response_class=HTMLResponse)
def index():
    return FileResponse(str(STATIC_DIR / "index.html"))

@app.get("/api/health")
def health():
    return {
        "ok": True,
        "have_colmap": which("colmap") is not None,
        "have_meshroom": which("meshroom_batch") is not None,
        "have_ffmpeg": which("ffmpeg") is not None,
    }

# -------- Relief endpoint --------

@app.post("/api/relief/convert")
async def relief_convert(
    image: UploadFile = File(...),
    params: str = Form(default=json.dumps(RELIEF_DEFAULTS)),
):
    p = RELIEF_DEFAULTS.copy()
    try:
        incoming = json.loads(params)
        if isinstance(incoming, dict):
            p.update(incoming)
    except Exception:
        pass

    fmt = str(p.get("format", "stl")).lower().strip(".")
    if fmt not in SUPPORTED_EXPORTS:
        return JSONResponse({"error": f"Unsupported format '{fmt}'"}, status_code=400)

    img_bytes = await image.read()
    crop = safe_float_list(p.get("crop", [0, 0, 1, 1]), 4, [0, 0, 1, 1])

    mesh = image_to_relief_mesh(
        image_bytes=img_bytes,
        mode=str(p.get("mode", "relief")),
        width_mm=float(p.get("width_mm", 120.0)),
        base_mm=float(p.get("base_mm", 2.0)),
        relief_mm=float(p.get("relief_mm", 3.0)),
        pixels_wide=int(p.get("pixels_wide", 420)),
        crop=(float(crop[0]), float(crop[1]), float(crop[2]), float(crop[3])),
        invert=bool(p.get("invert", False)),
        blur=float(p.get("blur", 1.0)),
        black=float(p.get("black", 0.0)),
        white=float(p.get("white", 1.0)),
        gamma=float(p.get("gamma", 1.0)),
        auto_contrast=bool(p.get("auto_contrast", True)),
    )

    out = export_mesh(mesh, fmt)
    media = {
        "stl":"model/stl",
        "obj":"text/plain",
        "ply":"application/octet-stream",
        "glb":"model/gltf-binary"
    }.get(fmt, "application/octet-stream")
    return Response(
        content=out,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="relief.{fmt}"'},
    )

# -------- Figurine: start job --------

@app.post("/api/figurine/start")
async def figurine_start(
    params: str = Form(default=json.dumps(FIGURINE_DEFAULTS)),
    images: Optional[List[UploadFile]] = File(default=None),
    zipfile_up: Optional[UploadFile] = File(default=None, alias="zipfile"),
    video: Optional[UploadFile] = File(default=None),
):
    p = FIGURINE_DEFAULTS.copy()
    try:
        incoming = json.loads(params)
        if isinstance(incoming, dict):
            p.update(incoming)
    except Exception:
        pass

    fmt = str(p.get("format", "stl")).lower().strip(".")
    if fmt not in SUPPORTED_EXPORTS:
        return JSONResponse({"error": f"Unsupported format '{fmt}'"}, status_code=400)

    job = JOBS.create(kind="figurine")
    work_dir = Path(tempfile.mkdtemp(prefix=f"img3d_job_{job.id}_"))
    imgs_dir = work_dir / "images"
    imgs_dir.mkdir(parents=True, exist_ok=True)

    # Save uploads
    if zipfile_up is not None:
        zbytes = await zipfile_up.read()
        zpath = work_dir / "upload.zip"
        zpath.write_bytes(zbytes)
        with zipfile.ZipFile(str(zpath), "r") as z:
            z.extractall(str(imgs_dir))
    elif video is not None:
        vbytes = await video.read()
        ext = Path(video.filename or "").suffix or ".mp4"
        vpath = (work_dir / "upload_video").with_suffix(ext)
        vpath.write_bytes(vbytes)
        def _log(m): JOBS.log(job.id, m)
        try:
            extract_frames_with_ffmpeg(
                vpath, imgs_dir,
                frame_step=int(p.get("frame_step", 6)),
                max_frames=int(p.get("max_frames", 160)),
                log_cb=_log
            )
        except Exception as e:
            JOBS.set_error(job.id, str(e))
            return JSONResponse({"job_id": job.id, "error": str(e)}, status_code=400)
    else:
        if not images:
            return JSONResponse({"error": "No images/zip/video provided."}, status_code=400)
        for f in images:
            b = await f.read()
            name = Path(f.filename or f"img_{uuid.uuid4().hex}.jpg").name
            (imgs_dir / name).write_bytes(b)

    def worker():
        def log(m: str): JOBS.log(job.id, m)
        try:
            JOBS.set_status(job.id, "running", 0.02)

            img_list = sanitize_images(imgs_dir)
            if len(img_list) < 10:
                raise RuntimeError(f"Need at least ~10 images for a figurine. Found {len(img_list)}.")

            max_images = int(p.get("max_images", 160))
            img_list = sample_images(img_list, max_images)

            # If we sampled, rebuild the folder to only contain used images (simplifies COLMAP)
            if len(img_list) != len(sanitize_images(imgs_dir)):
                tmp = work_dir / "images_used"
                tmp.mkdir(parents=True, exist_ok=True)
                for i, src in enumerate(img_list):
                    dst = tmp / f"img_{i:04d}{src.suffix.lower()}"
                    shutil.copy2(src, dst)
                shutil.rmtree(imgs_dir)
                tmp.rename(imgs_dir)
                img_list = sanitize_images(imgs_dir)

            engine = choose_engine(str(p.get("engine","auto")), str(p.get("device","auto")))
            if engine == "none":
                raise RuntimeError("No photogrammetry engine found. Install COLMAP or Meshroom (and optionally ffmpeg).")

            device = str(p.get("device","auto")).lower()
            use_gpu = (device == "gpu")
            if device == "auto":
                use_gpu = (engine == "meshroom")  # best guess

            quality = str(p.get("quality","medium")).lower()
            mesher = str(p.get("mesher","poisson")).lower()

            log(f"Images: {len(img_list)} (max_images={max_images})")
            log(f"Engine: {engine} • Device: {'GPU' if use_gpu else 'CPU'} • Quality: {quality} • Mesher: {mesher}")
            JOBS.set_status(job.id, "running", 0.06)

            if engine == "meshroom":
                log("Running Meshroom…")
                mesh_path = run_meshroom(imgs_dir, work_dir, log_cb=log)
                JOBS.set_status(job.id, "running", 0.72)
                log(f"Meshroom produced: {mesh_path}")
                mesh = load_any_mesh(mesh_path)
            else:
                log("Running COLMAP dense reconstruction…")
                dense_dir = run_colmap_to_dense(imgs_dir, work_dir, use_gpu=use_gpu, quality=quality, log_cb=log)
                JOBS.set_status(job.id, "running", 0.78)
                log("Running COLMAP mesher…")
                mesh_path = run_colmap_mesher(dense_dir, mesher, log_cb=log)
                JOBS.set_status(job.id, "running", 0.90)
                log(f"COLMAP mesh: {mesh_path}")
                mesh = load_any_mesh(mesh_path)

            # Export
            fmt = str(p.get("format","stl")).lower().strip(".")
            out_bytes = export_mesh(mesh, fmt)
            out_path = work_dir / f"result.{fmt}"
            out_path.write_bytes(out_bytes)
            JOBS.set_result(job.id, out_path, fmt)
            log("DONE.")
        except Exception as e:
            JOBS.set_error(job.id, str(e))
            log(f"ERROR: {e}")

    threading.Thread(target=worker, daemon=True).start()
    return {"job_id": job.id}

# -------- Job status + download --------

@app.get("/api/job/{job_id}")
def job_status(job_id: str):
    j = JOBS.get(job_id)
    if not j:
        return JSONResponse({"error": "job not found"}, status_code=404)
    return {
        "job_id": j.id,
        "kind": j.kind,
        "status": j.status,
        "progress": j.progress,
        "error": j.error,
        "result_path": j.result_path,
        "result_fmt": j.result_fmt,
        "logs": j.logs[-300:],
    }

@app.get("/api/job/{job_id}/download")
def job_download(job_id: str):
    j = JOBS.get(job_id)
    if not j or j.status != "done" or not j.result_path:
        return JSONResponse({"error": "job not ready"}, status_code=400)
    path = Path(j.result_path)
    if not path.exists():
        return JSONResponse({"error": "result missing"}, status_code=404)

    fmt = (j.result_fmt or path.suffix.lstrip(".") or "stl").lower()
    media = {"stl":"model/stl","obj":"text/plain","ply":"application/octet-stream","glb":"model/gltf-binary"}.get(fmt, "application/octet-stream")
    return Response(
        content=path.read_bytes(),
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="figurine.{fmt}"'},
    )

if __name__ == "__main__":
    import uvicorn
    print(f"▶ {APP_TITLE}")
    print(f"▶ Open: http://{HOST}:{PORT}")
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
