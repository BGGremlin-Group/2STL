#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IMG3D Exporter — Windows Python GUI (No HTML)
- Relief/Lithophane: single image -> watertight mesh -> export STL/OBJ/PLY/GLB
- Figurine: multi-angle images/ZIP/video -> photogrammetry (COLMAP or Meshroom) -> export

Dependencies (pip):
- PySide6, pillow, numpy, trimesh, pygltflib

External tools (figurine mode):
- COLMAP (colmap.exe) OR Meshroom (meshroom_batch.exe)
- FFmpeg (ffmpeg.exe) for video -> frames extraction
"""

from __future__ import annotations

import io
import os
import sys
import json
import time
import uuid
import math
import glob
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image, ImageFilter, ImageOps
import trimesh

from PySide6 import QtCore, QtGui, QtWidgets


SUPPORTED_EXPORTS = ("stl", "obj", "ply", "glb")


# -------------------------
# Utility / subprocess
# -------------------------

def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)

def run_cmd(cmd: List[str], cwd: Optional[Path] = None, env: Optional[Dict[str, str]] = None, log_cb=None) -> None:
    if log_cb:
        log_cb(f"$ {' '.join(cmd)}")
    p = subprocess.Popen(
        cmd,
        cwd=str(cwd) if cwd else None,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
    )
    assert p.stdout is not None
    for line in p.stdout:
        line = line.rstrip("\n")
        if line and log_cb:
            log_cb(line)
    rc = p.wait()
    if rc != 0:
        raise RuntimeError(f"Command failed (exit {rc}): {' '.join(cmd)}")


# -------------------------
# Relief / Lithophane mesh
# -------------------------

def _as_float01(gray: Image.Image) -> np.ndarray:
    arr = np.asarray(gray, dtype=np.float32) / 255.0
    return np.clip(arr, 0.0, 1.0)

def _apply_levels(h: np.ndarray, black=0.0, white=1.0, gamma=1.0) -> np.ndarray:
    black = float(np.clip(black, 0.0, 1.0))
    white = float(np.clip(white, 0.0, 1.0))
    if white <= black + 1e-6:
        white = min(1.0, black + 1e-6)
    h = np.clip(h, black, white)
    h = (h - black) / (white - black)
    gamma = max(0.05, float(gamma))
    h = np.power(h, 1.0 / gamma)
    return h

def image_to_relief_mesh(
    image_bytes: bytes,
    mode: str = "relief",
    width_mm: float = 120.0,
    base_mm: float = 2.0,
    relief_mm: float = 3.0,
    pixels_wide: int = 420,
    crop: Tuple[float, float, float, float] = (0, 0, 1, 1),
    invert: bool = False,
    blur: float = 1.0,
    black: float = 0.0,
    white: float = 1.0,
    gamma: float = 1.0,
    auto_contrast: bool = True,
) -> trimesh.Trimesh:
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")

    # Crop by fractional box
    W, H = img.size
    l, t, r, b = crop
    lpx = int(np.clip(l, 0, 1) * W)
    tpx = int(np.clip(t, 0, 1) * H)
    rpx = int(np.clip(r, 0, 1) * W)
    bpx = int(np.clip(b, 0, 1) * H)
    if rpx <= lpx + 2:
        rpx = min(W, lpx + 2)
    if bpx <= tpx + 2:
        bpx = min(H, tpx + 2)
    img = img.crop((lpx, tpx, rpx, bpx))

    # Resize preserve aspect
    w_target = int(max(96, pixels_wide))
    aspect = img.size[1] / img.size[0]
    h_target = int(max(96, round(w_target * aspect)))
    img = img.resize((w_target, h_target), Image.LANCZOS)

    gray = ImageOps.grayscale(img)
    if blur and float(blur) > 0:
        gray = gray.filter(ImageFilter.GaussianBlur(radius=float(blur)))

    h = _as_float01(gray)

    if mode.lower() == "lithophane":
        # Lithophanes often want inversion so bright areas become thinner, but we let user control
        pass

    if invert:
        h = 1.0 - h

    if auto_contrast:
        hmin, hmax = float(h.min()), float(h.max())
        if hmax > hmin + 1e-6:
            h = (h - hmin) / (hmax - hmin)

    h = _apply_levels(h, black=black, white=white, gamma=gamma)

    width_mm = float(width_mm)
    height_mm = width_mm * (h_target / w_target)
    base_mm = float(base_mm)
    relief_mm = float(relief_mm)

    xs = np.linspace(0.0, width_mm, w_target, dtype=np.float32)
    ys = np.linspace(0.0, height_mm, h_target, dtype=np.float32)
    X, Y = np.meshgrid(xs, ys)
    Z_top = (base_mm + h * relief_mm).astype(np.float32)
    Z_bot = np.zeros_like(Z_top, dtype=np.float32)

    v_top = np.column_stack([X.ravel(), Y.ravel(), Z_top.ravel()]).astype(np.float32)
    v_bot = np.column_stack([X.ravel(), Y.ravel(), Z_bot.ravel()]).astype(np.float32)

    def idx(i: int, j: int) -> int:
        return j * w_target + i

    faces: List[List[int]] = []

    # Top surface
    for j in range(h_target - 1):
        for i in range(w_target - 1):
            a = idx(i, j)
            b = idx(i + 1, j)
            c = idx(i + 1, j + 1)
            d = idx(i, j + 1)
            faces.append([a, b, c])
            faces.append([a, c, d])

    # Bottom surface (reverse winding)
    off = v_top.shape[0]
    for j in range(h_target - 1):
        for i in range(w_target - 1):
            a = off + idx(i, j)
            b = off + idx(i, j + 1)
            c = off + idx(i + 1, j + 1)
            d = off + idx(i + 1, j)
            faces.append([a, b, c])
            faces.append([a, c, d])

    # Side walls
    for j in range(h_target - 1):  # left
        a = idx(0, j)
        b = idx(0, j + 1)
        c = off + idx(0, j + 1)
        d = off + idx(0, j)
        faces.append([a, b, c])
        faces.append([a, c, d])

    for j in range(h_target - 1):  # right
        a = idx(w_target - 1, j)
        b = off + idx(w_target - 1, j)
        c = off + idx(w_target - 1, j + 1)
        d = idx(w_target - 1, j + 1)
        faces.append([a, b, c])
        faces.append([a, c, d])

    for i in range(w_target - 1):  # bottom edge
        a = idx(i, 0)
        b = off + idx(i, 0)
        c = off + idx(i + 1, 0)
        d = idx(i + 1, 0)
        faces.append([a, b, c])
        faces.append([a, c, d])

    for i in range(w_target - 1):  # top edge
        a = idx(i, h_target - 1)
        b = idx(i + 1, h_target - 1)
        c = off + idx(i + 1, h_target - 1)
        d = off + idx(i, h_target - 1)
        faces.append([a, b, c])
        faces.append([a, c, d])

    vertices = np.vstack([v_top, v_bot])
    faces_np = np.asarray(faces, dtype=np.int64)

    mesh = trimesh.Trimesh(vertices=vertices, faces=faces_np, process=True)
    mesh.remove_duplicate_faces()
    mesh.remove_degenerate_faces()
    mesh.remove_unreferenced_vertices()
    mesh.fix_normals()
    return mesh

def export_mesh(mesh: trimesh.Trimesh, fmt: str) -> bytes:
    fmt = fmt.lower().strip(".")
    if fmt not in SUPPORTED_EXPORTS:
        raise ValueError(f"Unsupported format: {fmt}")
    out = mesh.export(file_type=fmt)
    if isinstance(out, str):
        return out.encode("utf-8")
    return out

def load_any_mesh(path: Path) -> trimesh.Trimesh:
    m = trimesh.load(str(path), force="mesh")
    if isinstance(m, trimesh.Scene):
        m = trimesh.util.concatenate(tuple(m.dump().geometry.values()))
    assert isinstance(m, trimesh.Trimesh)
    m.remove_duplicate_faces()
    m.remove_degenerate_faces()
    m.remove_unreferenced_vertices()
    m.fix_normals()
    return m


# -------------------------
# Figurine: COLMAP / Meshroom / FFmpeg
# -------------------------

def sanitize_images(folder: Path) -> List[Path]:
    exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
    imgs = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in exts]
    return sorted(imgs, key=lambda p: p.name.lower())

def sample_images(files: List[Path], max_images: int) -> List[Path]:
    if max_images <= 0 or len(files) <= max_images:
        return files
    idx = np.linspace(0, len(files) - 1, max_images).astype(int)
    return [files[i] for i in idx]

def extract_frames_with_ffmpeg(video_path: Path, out_dir: Path, frame_step: int, max_frames: int, log_cb=None) -> None:
    if not which("ffmpeg"):
        raise RuntimeError("ffmpeg.exe not found in PATH. Install FFmpeg or use images/ZIP instead of video.")
    out_dir.mkdir(parents=True, exist_ok=True)
    pattern = str(out_dir / "frame_%05d.jpg")
    vf = f"select='not(mod(n\\,{frame_step}))',scale=1600:-1"
    cmd = ["ffmpeg", "-y", "-i", str(video_path), "-vf", vf, "-q:v", "2", pattern]
    run_cmd(cmd, cwd=out_dir, log_cb=log_cb)

    frames = sorted(out_dir.glob("frame_*.jpg"))
    if len(frames) > max_frames:
        for p in frames[max_frames:]:
            p.unlink(missing_ok=True)
        if log_cb:
            log_cb(f"Trimmed frames to max_frames={max_frames}.")

def find_meshroom_mesh(output_dir: Path) -> Optional[Path]:
    candidates = []
    candidates += glob.glob(str(output_dir / "**" / "texturedMesh.obj"), recursive=True)
    candidates += glob.glob(str(output_dir / "**" / "texturedMesh.ply"), recursive=True)
    candidates += glob.glob(str(output_dir / "**" / "mesh.obj"), recursive=True)
    candidates += glob.glob(str(output_dir / "**" / "mesh.ply"), recursive=True)
    if not candidates:
        return None
    candidates = sorted(candidates, key=lambda s: (0 if "texturedMesh.obj" in s else 1, len(s)))
    return Path(candidates[0])

def run_meshroom(images_dir: Path, work_dir: Path, log_cb=None) -> Path:
    exe = which("meshroom_batch")
    if not exe:
        raise RuntimeError("meshroom_batch.exe not found in PATH. Install Meshroom or use COLMAP engine.")
    out_dir = work_dir / "meshroom_out"
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [exe, "--input", str(images_dir), "--output", str(out_dir)]
    run_cmd(cmd, cwd=work_dir, log_cb=log_cb)
    mesh_path = find_meshroom_mesh(out_dir)
    if not mesh_path or not mesh_path.exists():
        raise RuntimeError("Meshroom finished but no mesh was found in output.")
    return mesh_path

def run_colmap_to_dense(images_dir: Path, work_dir: Path, use_gpu: bool, quality: str, log_cb=None) -> Path:
    exe = which("colmap")
    if not exe:
        raise RuntimeError("colmap.exe not found in PATH. Install COLMAP, or use Meshroom engine.")

    db = work_dir / "database.db"
    sparse = work_dir / "sparse"
    dense = work_dir / "dense"
    sparse.mkdir(exist_ok=True)
    dense.mkdir(exist_ok=True)

    if quality == "draft":
        pm_geom = "false"
        pm_iters = "3"
    elif quality == "high":
        pm_geom = "true"
        pm_iters = "7"
    else:
        pm_geom = "true"
        pm_iters = "5"

    gpu_flag = "1" if use_gpu else "0"

    run_cmd([
        exe, "feature_extractor",
        "--database_path", str(db),
        "--image_path", str(images_dir),
        "--ImageReader.single_camera", "1",
        "--SiftExtraction.use_gpu", gpu_flag,
    ], cwd=work_dir, log_cb=log_cb)

    run_cmd([
        exe, "exhaustive_matcher",
        "--database_path", str(db),
        "--SiftMatching.use_gpu", gpu_flag,
    ], cwd=work_dir, log_cb=log_cb)

    run_cmd([
        exe, "mapper",
        "--database_path", str(db),
        "--image_path", str(images_dir),
        "--output_path", str(sparse),
    ], cwd=work_dir, log_cb=log_cb)

    models = sorted([p for p in sparse.iterdir() if p.is_dir()], key=lambda p: p.name)
    if not models:
        raise RuntimeError("COLMAP mapper produced no sparse model.")
    model = models[-1]

    run_cmd([
        exe, "image_undistorter",
        "--image_path", str(images_dir),
        "--input_path", str(model),
        "--output_path", str(dense),
        "--output_type", "COLMAP",
    ], cwd=work_dir, log_cb=log_cb)

    run_cmd([
        exe, "patch_match_stereo",
        "--workspace_path", str(dense),
        "--workspace_format", "COLMAP",
        "--PatchMatchStereo.geom_consistency", pm_geom,
        "--PatchMatchStereo.max_num_iterations", pm_iters,
        "--PatchMatchStereo.gpu_index", "0",
        "--PatchMatchStereo.use_gpu", gpu_flag,
    ], cwd=work_dir, log_cb=log_cb)

    fused = dense / "fused.ply"
    run_cmd([
        exe, "stereo_fusion",
        "--workspace_path", str(dense),
        "--workspace_format", "COLMAP",
        "--input_type", "geometric",
        "--output_path", str(fused),
    ], cwd=work_dir, log_cb=log_cb)

    if not fused.exists():
        raise RuntimeError("COLMAP stereo_fusion did not produce fused.ply.")
    return dense

def run_colmap_mesher(dense_dir: Path, method: str, log_cb=None) -> Path:
    exe = which("colmap")
    if not exe:
        raise RuntimeError("colmap.exe not found in PATH.")
    fused = dense_dir / "fused.ply"
    if not fused.exists():
        raise RuntimeError("Expected fused.ply not found. Dense reconstruction probably failed.")

    method = (method or "poisson").lower()
    if method not in ("poisson", "delaunay"):
        method = "poisson"

    out_path = dense_dir / f"meshed-{method}.ply"
    if method == "poisson":
        cmd = [exe, "poisson_mesher", "--input_path", str(fused), "--output_path", str(out_path)]
    else:
        cmd = [exe, "delaunay_mesher", "--input_path", str(fused), "--output_path", str(out_path)]
    run_cmd(cmd, cwd=dense_dir, log_cb=log_cb)

    if not out_path.exists():
        raise RuntimeError(f"COLMAP {method}_mesher did not produce output mesh.")
    return out_path

def choose_engine(engine: str, device: str) -> str:
    engine = (engine or "auto").lower()
    device = (device or "auto").lower()
    have_colmap = which("colmap") is not None
    have_meshroom = which("meshroom_batch") is not None
    if engine != "auto":
        return engine
    if device == "gpu" and have_meshroom:
        return "meshroom"
    if have_colmap:
        return "colmap"
    if have_meshroom:
        return "meshroom"
    return "none"


# -------------------------
# Qt Helpers
# -------------------------

def qpix_from_pil(img: Image.Image, max_w: int = 360, max_h: int = 240) -> QtGui.QPixmap:
    # Keep aspect
    im = img.copy().convert("RGB")
    im.thumbnail((max_w, max_h), Image.LANCZOS)
    data = im.tobytes("raw", "RGB")
    qimg = QtGui.QImage(data, im.size[0], im.size[1], QtGui.QImage.Format_RGB888)
    return QtGui.QPixmap.fromImage(qimg)

def human_bytes(n: int) -> str:
    units = ["B","KB","MB","GB"]
    f = float(n)
    for u in units:
        if f < 1024 or u == units[-1]:
            return f"{f:.1f}{u}" if u != "B" else f"{int(f)}B"
        f /= 1024.0
    return f"{n}B"


# -------------------------
# Worker Threads
# -------------------------

class ReliefWorker(QtCore.QThread):
    log = QtCore.Signal(str)
    done = QtCore.Signal(bytes, str)  # data, fmt
    failed = QtCore.Signal(str)

    def __init__(self, image_path: Path, params: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.params = params

    def run(self):
        try:
            self.log.emit("Reading image…")
            img_bytes = self.image_path.read_bytes()

            self.log.emit("Generating mesh…")
            mesh = image_to_relief_mesh(
                image_bytes=img_bytes,
                mode=self.params["mode"],
                width_mm=float(self.params["width_mm"]),
                base_mm=float(self.params["base_mm"]),
                relief_mm=float(self.params["relief_mm"]),
                pixels_wide=int(self.params["pixels_wide"]),
                crop=tuple(self.params["crop"]),
                invert=bool(self.params["invert"]),
                blur=float(self.params["blur"]),
                black=float(self.params["black"]),
                white=float(self.params["white"]),
                gamma=float(self.params["gamma"]),
                auto_contrast=bool(self.params["auto_contrast"]),
            )
            fmt = str(self.params["format"]).lower().strip(".")
            self.log.emit(f"Exporting {fmt.upper()}…")
            out = export_mesh(mesh, fmt)
            self.done.emit(out, fmt)
        except Exception as e:
            self.failed.emit(str(e))


class FigurineWorker(QtCore.QThread):
    log = QtCore.Signal(str)
    progress = QtCore.Signal(float)
    done = QtCore.Signal(bytes, str)
    failed = QtCore.Signal(str)

    def __init__(self, input_kind: str, input_paths: List[Path], params: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.input_kind = input_kind  # "folder" | "zip" | "video"
        self.input_paths = input_paths
        self.params = params

    def run(self):
        work_dir = Path(tempfile.mkdtemp(prefix="img3d_gui_job_"))
        imgs_dir = work_dir / "images"
        imgs_dir.mkdir(parents=True, exist_ok=True)

        def _log(m: str):
            self.log.emit(m)

        try:
            self.progress.emit(0.02)
            _log(f"Work dir: {work_dir}")

            # Gather inputs
            if self.input_kind == "folder":
                folder = self.input_paths[0]
                _log(f"Using folder: {folder}")
                for p in sanitize_images(folder):
                    shutil.copy2(p, imgs_dir / p.name)

            elif self.input_kind == "zip":
                z = self.input_paths[0]
                _log(f"Extracting ZIP: {z}")
                with zipfile.ZipFile(str(z), "r") as zf:
                    zf.extractall(str(imgs_dir))

            elif self.input_kind == "video":
                v = self.input_paths[0]
                _log(f"Extracting frames from video: {v}")
                extract_frames_with_ffmpeg(
                    v, imgs_dir,
                    frame_step=int(self.params["frame_step"]),
                    max_frames=int(self.params["max_frames"]),
                    log_cb=_log
                )
            else:
                raise RuntimeError("Unknown input kind.")

            # Validate images
            img_list = sanitize_images(imgs_dir)
            if len(img_list) < 10:
                raise RuntimeError(f"Need at least ~10 images for figurine. Found {len(img_list)}.")
            max_images = int(self.params["max_images"])
            img_list = sample_images(img_list, max_images)

            # If sampled, keep only sampled images
            if len(img_list) != len(sanitize_images(imgs_dir)):
                _log(f"Sampling images: keeping {len(img_list)} of {len(sanitize_images(imgs_dir))}")
                tmp = work_dir / "images_used"
                tmp.mkdir(parents=True, exist_ok=True)
                for i, src in enumerate(img_list):
                    dst = tmp / f"img_{i:04d}{src.suffix.lower()}"
                    shutil.copy2(src, dst)
                shutil.rmtree(imgs_dir)
                tmp.rename(imgs_dir)
                img_list = sanitize_images(imgs_dir)

            engine = choose_engine(str(self.params["engine"]), str(self.params["device"]))
            if engine == "none":
                raise RuntimeError("No photogrammetry engine found. Install COLMAP or Meshroom (FFmpeg needed for video).")

            device = str(self.params["device"]).lower()
            use_gpu = (device == "gpu")
            if device == "auto":
                use_gpu = (engine == "meshroom")  # best guess

            quality = str(self.params["quality"]).lower()
            mesher = str(self.params["mesher"]).lower()
            fmt = str(self.params["format"]).lower().strip(".")

            _log(f"Images: {len(img_list)} (max_images={max_images})")
            _log(f"Engine: {engine} • Device: {'GPU' if use_gpu else 'CPU'} • Quality: {quality} • Mesher: {mesher}")
            self.progress.emit(0.08)

            if engine == "meshroom":
                _log("Running Meshroom… (this can take a while)")
                mesh_path = run_meshroom(imgs_dir, work_dir, log_cb=_log)
                self.progress.emit(0.70)
                _log(f"Meshroom produced: {mesh_path}")
                mesh = load_any_mesh(mesh_path)
            else:
                _log("Running COLMAP dense reconstruction… (this can take a while)")
                dense_dir = run_colmap_to_dense(imgs_dir, work_dir, use_gpu=use_gpu, quality=quality, log_cb=_log)
                self.progress.emit(0.78)
                _log("Running COLMAP mesher…")
                mesh_path = run_colmap_mesher(dense_dir, mesher, log_cb=_log)
                self.progress.emit(0.90)
                _log(f"COLMAP mesh: {mesh_path}")
                mesh = load_any_mesh(mesh_path)

            _log(f"Exporting {fmt.upper()}…")
            out = export_mesh(mesh, fmt)
            self.progress.emit(1.0)
            self.done.emit(out, fmt)
        except Exception as e:
            self.failed.emit(str(e))
        finally:
            # Keep work_dir for debugging if desired; set env var IMG3D_KEEP_WORK=1 to keep
            if os.environ.get("IMG3D_KEEP_WORK", "0") != "1":
                try:
                    shutil.rmtree(work_dir)
                except Exception:
                    pass


# -------------------------
# GUI
# -------------------------

class ReliefTab(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.image_path: Optional[Path] = None
        self.last_output: Optional[bytes] = None
        self.last_fmt: str = "stl"

        # Layout
        root = QtWidgets.QVBoxLayout(self)
        root.setSpacing(10)

        # File picker row
        file_row = QtWidgets.QHBoxLayout()
        self.btn_pick = QtWidgets.QPushButton("Choose image…")
        self.lbl_file = QtWidgets.QLabel("No image selected.")
        self.lbl_file.setWordWrap(True)
        file_row.addWidget(self.btn_pick)
        file_row.addWidget(self.lbl_file, 1)
        root.addLayout(file_row)

        # Image preview
        self.img_preview = QtWidgets.QLabel()
        self.img_preview.setMinimumHeight(200)
        self.img_preview.setAlignment(QtCore.Qt.AlignCenter)
        self.img_preview.setStyleSheet("border:1px solid #2a3548; border-radius:10px; background:#0e131b;")
        root.addWidget(self.img_preview)

        # Params grid
        grid = QtWidgets.QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)

        self.mode = QtWidgets.QComboBox()
        self.mode.addItems(["relief", "lithophane"])

        self.fmt = QtWidgets.QComboBox()
        self.fmt.addItems(["stl","obj","ply","glb"])

        self.pixels = QtWidgets.QSpinBox(); self.pixels.setRange(96, 2000); self.pixels.setSingleStep(32); self.pixels.setValue(420)
        self.width = QtWidgets.QDoubleSpinBox(); self.width.setRange(20, 800); self.width.setDecimals(1); self.width.setValue(120.0)
        self.base = QtWidgets.QDoubleSpinBox(); self.base.setRange(0.4, 40); self.base.setDecimals(2); self.base.setValue(2.0)
        self.relief = QtWidgets.QDoubleSpinBox(); self.relief.setRange(0.4, 40); self.relief.setDecimals(2); self.relief.setValue(3.0)
        self.blur = QtWidgets.QDoubleSpinBox(); self.blur.setRange(0, 10); self.blur.setDecimals(2); self.blur.setValue(1.0)

        self.invert = QtWidgets.QCheckBox("Invert height")
        self.autocontrast = QtWidgets.QCheckBox("Auto-contrast")
        self.autocontrast.setChecked(True)

        self.black = QtWidgets.QDoubleSpinBox(); self.black.setRange(0, 1); self.black.setDecimals(3); self.black.setSingleStep(0.01); self.black.setValue(0.0)
        self.white = QtWidgets.QDoubleSpinBox(); self.white.setRange(0, 1); self.white.setDecimals(3); self.white.setSingleStep(0.01); self.white.setValue(1.0)
        self.gamma = QtWidgets.QDoubleSpinBox(); self.gamma.setRange(0.2, 3.0); self.gamma.setDecimals(2); self.gamma.setSingleStep(0.05); self.gamma.setValue(1.0)

        self.crop = QtWidgets.QLineEdit("0,0,1,1")

        row = 0
        grid.addWidget(QtWidgets.QLabel("Mode"), row, 0); grid.addWidget(self.mode, row, 1)
        grid.addWidget(QtWidgets.QLabel("Export"), row, 2); grid.addWidget(self.fmt, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Resolution (px wide)"), row, 0); grid.addWidget(self.pixels, row, 1)
        grid.addWidget(QtWidgets.QLabel("Width (mm)"), row, 2); grid.addWidget(self.width, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Base thickness (mm)"), row, 0); grid.addWidget(self.base, row, 1)
        grid.addWidget(QtWidgets.QLabel("Relief height (mm)"), row, 2); grid.addWidget(self.relief, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Blur (smoothing)"), row, 0); grid.addWidget(self.blur, row, 1)
        grid.addWidget(self.invert, row, 2); grid.addWidget(self.autocontrast, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Black point (0-1)"), row, 0); grid.addWidget(self.black, row, 1)
        grid.addWidget(QtWidgets.QLabel("White point (0-1)"), row, 2); grid.addWidget(self.white, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Gamma"), row, 0); grid.addWidget(self.gamma, row, 1)
        grid.addWidget(QtWidgets.QLabel("Crop (l,t,r,b)"), row, 2); grid.addWidget(self.crop, row, 3); row += 1

        root.addLayout(grid)

        # Presets row
        preset_row = QtWidgets.QHBoxLayout()
        self.btn_plaque = QtWidgets.QPushButton("Plaque")
        self.btn_coin = QtWidgets.QPushButton("Coin")
        self.btn_keychain = QtWidgets.QPushButton("Keychain")
        self.btn_litho = QtWidgets.QPushButton("Lithophane")
        for b in (self.btn_plaque, self.btn_coin, self.btn_keychain, self.btn_litho):
            preset_row.addWidget(b)
        root.addLayout(preset_row)

        # Action buttons
        act = QtWidgets.QHBoxLayout()
        self.btn_preview = QtWidgets.QPushButton("Generate (preview in app)")
        self.btn_save = QtWidgets.QPushButton("Save export…")
        self.btn_preview.setEnabled(False)
        self.btn_save.setEnabled(False)
        act.addWidget(self.btn_preview, 1)
        act.addWidget(self.btn_save, 1)
        root.addLayout(act)

        # Status + log
        self.status = QtWidgets.QLabel("")
        self.status.setWordWrap(True)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(2000)
        root.addWidget(self.status)
        root.addWidget(self.log, 1)

        # Worker
        self.worker: Optional[ReliefWorker] = None

        # Connections
        self.btn_pick.clicked.connect(self.pick_image)
        self.btn_preview.clicked.connect(self.run_generate)
        self.btn_save.clicked.connect(self.save_output)
        self.btn_plaque.clicked.connect(lambda: self.apply_preset("plaque"))
        self.btn_coin.clicked.connect(lambda: self.apply_preset("coin"))
        self.btn_keychain.clicked.connect(lambda: self.apply_preset("keychain"))
        self.btn_litho.clicked.connect(lambda: self.apply_preset("litho"))

    def append_log(self, s: str):
        self.log.appendPlainText(s)

    def pick_image(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Choose image", "",
            "Images (*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff);;All files (*.*)"
        )
        if not path:
            return
        self.image_path = Path(path)
        self.lbl_file.setText(str(self.image_path))
        try:
            pil = Image.open(str(self.image_path)).convert("RGB")
            self.img_preview.setPixmap(qpix_from_pil(pil, 520, 320))
        except Exception as e:
            self.img_preview.setText("Could not preview image: " + str(e))

        self.btn_preview.setEnabled(True)
        self.btn_save.setEnabled(True)
        self.status.setText("Ready.")
        self.append_log(f"Selected image: {self.image_path.name} ({human_bytes(self.image_path.stat().st_size)})")

    def parse_crop(self) -> Tuple[float, float, float, float]:
        txt = self.crop.text().strip()
        try:
            parts = [float(x.strip()) for x in txt.split(",")]
            if len(parts) != 4:
                raise ValueError("Crop requires 4 comma-separated numbers.")
            parts = [max(0.0, min(1.0, p)) for p in parts]
            if parts[2] <= parts[0] + 1e-6 or parts[3] <= parts[1] + 1e-6:
                raise ValueError("Crop right/bottom must be greater than left/top.")
            return (parts[0], parts[1], parts[2], parts[3])
        except Exception as e:
            raise ValueError(f"Invalid crop '{txt}': {e}")

    def build_params(self) -> Dict[str, Any]:
        return {
            "mode": self.mode.currentText(),
            "format": self.fmt.currentText(),
            "pixels_wide": int(self.pixels.value()),
            "width_mm": float(self.width.value()),
            "base_mm": float(self.base.value()),
            "relief_mm": float(self.relief.value()),
            "blur": float(self.blur.value()),
            "invert": bool(self.invert.isChecked()),
            "auto_contrast": bool(self.autocontrast.isChecked()),
            "black": float(self.black.value()),
            "white": float(self.white.value()),
            "gamma": float(self.gamma.value()),
            "crop": list(self.parse_crop()),
        }

    def apply_preset(self, which: str):
        presets = {
            "plaque":  dict(mode="relief", width=140, base=2.2, relief=3.2, blur=1.2, pixels=520, invert=False, black=0.05, white=0.95, gamma=1.0, crop="0,0,1,1", ac=True),
            "coin":    dict(mode="relief", width=50,  base=2.4, relief=1.4, blur=1.4, pixels=420, invert=False, black=0.08, white=0.92, gamma=1.15, crop="0.12,0.08,0.88,0.92", ac=True),
            "keychain":dict(mode="relief", width=65,  base=2.8, relief=2.0, blur=1.8, pixels=420, invert=False, black=0.06, white=0.94, gamma=1.1, crop="0,0,1,1", ac=True),
            "litho":   dict(mode="lithophane", width=120, base=0.8, relief=2.4, blur=0.8, pixels=700, invert=True,  black=0.02, white=0.98, gamma=1.0, crop="0,0,1,1", ac=True),
        }
        p = presets[which]
        self.mode.setCurrentText(p["mode"])
        self.width.setValue(p["width"])
        self.base.setValue(p["base"])
        self.relief.setValue(p["relief"])
        self.blur.setValue(p["blur"])
        self.pixels.setValue(p["pixels"])
        self.invert.setChecked(p["invert"])
        self.black.setValue(p["black"])
        self.white.setValue(p["white"])
        self.gamma.setValue(p["gamma"])
        self.crop.setText(p["crop"])
        self.autocontrast.setChecked(p["ac"])
        self.append_log(f"Preset applied: {which}")

    def run_generate(self):
        if not self.image_path:
            return
        try:
            params = self.build_params()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Invalid parameters", str(e))
            return

        self.log.clear()
        self.append_log("Starting relief generation…")
        self.status.setText("Working…")
        self.btn_preview.setEnabled(False)
        self.btn_save.setEnabled(False)

        self.worker = ReliefWorker(self.image_path, params, self)
        self.worker.log.connect(self.append_log)
        self.worker.failed.connect(self._on_failed)
        self.worker.done.connect(self._on_done)
        self.worker.start()

    def _on_failed(self, msg: str):
        self.status.setText("Error: " + msg)
        self.append_log("ERROR: " + msg)
        self.btn_preview.setEnabled(True)
        self.btn_save.setEnabled(True)

    def _on_done(self, data: bytes, fmt: str):
        self.last_output = data
        self.last_fmt = fmt
        self.status.setText(f"Ready — generated {fmt.upper()} ({human_bytes(len(data))}).")
        self.append_log("Done.")
        self.btn_preview.setEnabled(True)
        self.btn_save.setEnabled(True)

        # Optional: quick visualization using trimesh if possible (non-blocking)
        # We do not auto-open a window; user can just save. This avoids window management issues.

    def save_output(self):
        if self.last_output is None:
            # If they didn't generate yet, generate first
            self.run_generate()
            return
        default_name = f"relief.{self.last_fmt}"
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save model", default_name,
            "3D Models (*.stl *.obj *.ply *.glb);;All files (*.*)"
        )
        if not path:
            return
        out_path = Path(path)
        out_path.write_bytes(self.last_output)
        self.append_log(f"Saved: {out_path}")
        self.status.setText(f"Saved: {out_path}")


class FigurineTab(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.input_kind: Optional[str] = None
        self.input_paths: List[Path] = []
        self.last_output: Optional[bytes] = None
        self.last_fmt: str = "stl"
        self.worker: Optional[FigurineWorker] = None

        root = QtWidgets.QVBoxLayout(self)
        root.setSpacing(10)

        # Engine detection
        detect_row = QtWidgets.QHBoxLayout()
        self.btn_detect = QtWidgets.QPushButton("Detect tools")
        self.lbl_tools = QtWidgets.QLabel("")
        self.lbl_tools.setWordWrap(True)
        detect_row.addWidget(self.btn_detect)
        detect_row.addWidget(self.lbl_tools, 1)
        root.addLayout(detect_row)

        # Input selection
        inp_group = QtWidgets.QGroupBox("Input")
        inp_layout = QtWidgets.QGridLayout(inp_group)
        self.btn_folder = QtWidgets.QPushButton("Choose folder of images…")
        self.btn_zip = QtWidgets.QPushButton("Choose ZIP of images…")
        self.btn_video = QtWidgets.QPushButton("Choose video…")
        self.lbl_input = QtWidgets.QLabel("No input selected.")
        self.lbl_input.setWordWrap(True)
        inp_layout.addWidget(self.btn_folder, 0, 0)
        inp_layout.addWidget(self.btn_zip, 0, 1)
        inp_layout.addWidget(self.btn_video, 0, 2)
        inp_layout.addWidget(self.lbl_input, 1, 0, 1, 3)
        root.addWidget(inp_group)

        # Params
        grid = QtWidgets.QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)

        self.engine = QtWidgets.QComboBox()
        self.engine.addItems(["auto", "colmap", "meshroom"])
        self.device = QtWidgets.QComboBox()
        self.device.addItems(["auto", "cpu", "gpu"])
        self.quality = QtWidgets.QComboBox()
        self.quality.addItems(["draft", "medium", "high"])
        self.quality.setCurrentText("medium")

        self.mesher = QtWidgets.QComboBox()
        self.mesher.addItems(["poisson", "delaunay"])
        self.mesher.setCurrentText("poisson")

        self.fmt = QtWidgets.QComboBox()
        self.fmt.addItems(["stl","obj","ply","glb"])

        self.frame_step = QtWidgets.QSpinBox(); self.frame_step.setRange(1, 30); self.frame_step.setValue(6)
        self.max_frames = QtWidgets.QSpinBox(); self.max_frames.setRange(30, 600); self.max_frames.setValue(160)
        self.max_images = QtWidgets.QSpinBox(); self.max_images.setRange(20, 500); self.max_images.setValue(160)

        row = 0
        grid.addWidget(QtWidgets.QLabel("Engine"), row, 0); grid.addWidget(self.engine, row, 1)
        grid.addWidget(QtWidgets.QLabel("Device"), row, 2); grid.addWidget(self.device, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Quality"), row, 0); grid.addWidget(self.quality, row, 1)
        grid.addWidget(QtWidgets.QLabel("Mesher (COLMAP)"), row, 2); grid.addWidget(self.mesher, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Export"), row, 0); grid.addWidget(self.fmt, row, 1)
        grid.addWidget(QtWidgets.QLabel("Max images (sample)"), row, 2); grid.addWidget(self.max_images, row, 3); row += 1

        grid.addWidget(QtWidgets.QLabel("Video frame step"), row, 0); grid.addWidget(self.frame_step, row, 1)
        grid.addWidget(QtWidgets.QLabel("Max video frames"), row, 2); grid.addWidget(self.max_frames, row, 3); row += 1

        root.addLayout(grid)

        # Actions
        act = QtWidgets.QHBoxLayout()
        self.btn_start = QtWidgets.QPushButton("Start job")
        self.btn_save = QtWidgets.QPushButton("Save result…")
        self.btn_start.setEnabled(False)
        self.btn_save.setEnabled(False)
        act.addWidget(self.btn_start, 1)
        act.addWidget(self.btn_save, 1)
        root.addLayout(act)

        # Progress + logs
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.status = QtWidgets.QLabel("")
        self.status.setWordWrap(True)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(4000)

        root.addWidget(self.progress)
        root.addWidget(self.status)
        root.addWidget(self.log, 1)

        # Connections
        self.btn_detect.clicked.connect(self.detect_tools)
        self.btn_folder.clicked.connect(self.pick_folder)
        self.btn_zip.clicked.connect(self.pick_zip)
        self.btn_video.clicked.connect(self.pick_video)
        self.btn_start.clicked.connect(self.start_job)
        self.btn_save.clicked.connect(self.save_output)

        self.detect_tools()

    def append_log(self, s: str):
        self.log.appendPlainText(s)

    def detect_tools(self):
        have_colmap = which("colmap") is not None
        have_meshroom = which("meshroom_batch") is not None
        have_ffmpeg = which("ffmpeg") is not None
        parts = [
            f"COLMAP: {'✅' if have_colmap else '❌'}",
            f"Meshroom: {'✅' if have_meshroom else '❌'}",
            f"FFmpeg: {'✅' if have_ffmpeg else '❌'}",
        ]
        self.lbl_tools.setText(" • ".join(parts))
        self.append_log("Tool detection: " + " • ".join(parts))

    def pick_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose folder of images", "")
        if not folder:
            return
        self.input_kind = "folder"
        self.input_paths = [Path(folder)]
        self.lbl_input.setText(str(folder))
        self.btn_start.setEnabled(True)
        self.append_log(f"Selected folder: {folder}")

    def pick_zip(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Choose ZIP", "", "ZIP (*.zip);;All files (*.*)")
        if not path:
            return
        self.input_kind = "zip"
        self.input_paths = [Path(path)]
        self.lbl_input.setText(str(path))
        self.btn_start.setEnabled(True)
        self.append_log(f"Selected ZIP: {path}")

    def pick_video(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Choose video", "", "Video (*.mp4 *.mov *.mkv *.avi);;All files (*.*)")
        if not path:
            return
        self.input_kind = "video"
        self.input_paths = [Path(path)]
        self.lbl_input.setText(str(path))
        self.btn_start.setEnabled(True)
        self.append_log(f"Selected video: {path}")

    def build_params(self) -> Dict[str, Any]:
        return {
            "engine": self.engine.currentText(),
            "device": self.device.currentText(),
            "quality": self.quality.currentText(),
            "mesher": self.mesher.currentText(),
            "format": self.fmt.currentText(),
            "frame_step": int(self.frame_step.value()),
            "max_frames": int(self.max_frames.value()),
            "max_images": int(self.max_images.value()),
        }

    def start_job(self):
        if not self.input_kind or not self.input_paths:
            return
        self.log.clear()
        self.last_output = None
        self.btn_save.setEnabled(False)

        params = self.build_params()
        self.status.setText("Working…")
        self.progress.setValue(2)
        self.btn_start.setEnabled(False)

        self.worker = FigurineWorker(self.input_kind, self.input_paths, params, self)
        self.worker.log.connect(self.append_log)
        self.worker.progress.connect(lambda p: self.progress.setValue(int(max(0, min(1, p)) * 100)))
        self.worker.failed.connect(self._on_failed)
        self.worker.done.connect(self._on_done)
        self.worker.start()

    def _on_failed(self, msg: str):
        self.status.setText("Error: " + msg)
        self.append_log("ERROR: " + msg)
        self.btn_start.setEnabled(True)
        self.btn_save.setEnabled(False)

    def _on_done(self, data: bytes, fmt: str):
        self.last_output = data
        self.last_fmt = fmt
        self.progress.setValue(100)
        self.status.setText(f"Done — generated {fmt.upper()} ({human_bytes(len(data))}).")
        self.append_log("DONE.")
        self.btn_start.setEnabled(True)
        self.btn_save.setEnabled(True)

    def save_output(self):
        if self.last_output is None:
            return
        default_name = f"figurine.{self.last_fmt}"
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save model", default_name,
            "3D Models (*.stl *.obj *.ply *.glb);;All files (*.*)"
        )
        if not path:
            return
        out_path = Path(path)
        out_path.write_bytes(self.last_output)
        self.append_log(f"Saved: {out_path}")
        self.status.setText(f"Saved: {out_path}")


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("IMG3D Exporter (Relief + Figurine) — Windows GUI")
        self.resize(1100, 720)

        tabs = QtWidgets.QTabWidget()
        tabs.addTab(ReliefTab(), "Relief / Lithophane")
        tabs.addTab(FigurineTab(), "Figurine (Photogrammetry)")
        self.setCentralWidget(tabs)

        # Dark palette
        self._apply_dark_theme()

    def _apply_dark_theme(self):
        app = QtWidgets.QApplication.instance()
        app.setStyle("Fusion")
        pal = QtGui.QPalette()
        pal.setColor(QtGui.QPalette.Window, QtGui.QColor("#0b0d10"))
        pal.setColor(QtGui.QPalette.WindowText, QtGui.QColor("#e9eef7"))
        pal.setColor(QtGui.QPalette.Base, QtGui.QColor("#0e131b"))
        pal.setColor(QtGui.QPalette.AlternateBase, QtGui.QColor("#11161f"))
        pal.setColor(QtGui.QPalette.ToolTipBase, QtGui.QColor("#11161f"))
        pal.setColor(QtGui.QPalette.ToolTipText, QtGui.QColor("#e9eef7"))
        pal.setColor(QtGui.QPalette.Text, QtGui.QColor("#e9eef7"))
        pal.setColor(QtGui.QPalette.Button, QtGui.QColor("#182033"))
        pal.setColor(QtGui.QPalette.ButtonText, QtGui.QColor("#e9eef7"))
        pal.setColor(QtGui.QPalette.BrightText, QtGui.QColor("#ff5a76"))
        pal.setColor(QtGui.QPalette.Highlight, QtGui.QColor("#2b5cff"))
        pal.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor("#ffffff"))
        app.setPalette(pal)


def main():
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
