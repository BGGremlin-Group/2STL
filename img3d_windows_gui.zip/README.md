# IMG3D Exporter — Windows Python GUI (No HTML)

A standalone **Windows desktop GUI** (Qt/PySide6) that converts:

1) **Single image → watertight bas‑relief / lithophane**
2) **Multi‑angle image set / ZIP / turntable video → figurine mesh** (photogrammetry via external engines)

Exports: **STL / OBJ / PLY / GLB**

> Relief mode is 100% Python and works anywhere Python runs.
> Figurine mode requires external photogrammetry tools (COLMAP or Meshroom; FFmpeg for video).

---

## Quick start (Windows)

### 1) Install Python deps
Open PowerShell in this folder:

```powershell
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

### 2) Run
```powershell
py img3d_gui.py
```

---

## Figurine mode prerequisites (choose one engine)

### Option A — COLMAP (CPU or CUDA GPU build)
- Install COLMAP and ensure `colmap.exe` is on PATH.
- CUDA acceleration depends on your COLMAP build.

### Option B — Meshroom (GPU-friendly)
- Install Meshroom and ensure `meshroom_batch.exe` is on PATH.

### Optional (video input)
- Install FFmpeg and ensure `ffmpeg.exe` is on PATH.

---

## Notes

- The GUI runs jobs in background threads and streams logs live.
- Outputs are saved to files you choose (no web server, no browser).
- If a tool is missing, the app explains what’s missing and how to fix it.

---

## Files
- `img3d_gui.py` — the complete GUI app (single file)
- `requirements.txt` — Python requirements

---

## License
MIT (see LICENSE in the previous zip if you want to reuse it).
